//Variable
//Constant

// // var greetings = "Hello World" //String
// var weight = 65 //Number
// var height = 5.11 //Decimal (Number)
// var isABoy = true //Boolean
// var isObject = {} //Object

// // console.log("Hello World") //To print something in the console of your browser

// // console.log(typeof greetings)

// let greetings = "Hello World"

// console.log(2/0)


// console.log(greetings)

let greetings = "Hello World"

console.log(printGreetings())

function printGreetings() {
    return greetings
}



















